//
//  KIFamilyHeadView.h
//  kibatina
//
//  Created by beyond on 2020/03/24.
//  Copyright © 2020 beyond. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface KIFamilyHeadView : UIView
@property (nonatomic,weak) IBOutlet UIImageView *xib_imgView_banner;
+ (instancetype)headView;
@end

NS_ASSUME_NONNULL_END
