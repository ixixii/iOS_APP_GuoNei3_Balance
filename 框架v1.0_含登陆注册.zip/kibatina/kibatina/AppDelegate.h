//
//  AppDelegate.h
//  kibatina
//
//  Created by beyond on 2020/03/20.
//  Copyright © 2020 beyond. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>
@property (strong, nonatomic) UIWindow * window;

@end

